# Ultra 5 225H — 5 hour NLP stress
# Run from this folder, laptop plugged in, Windows power plan = Best performance.
# Stops every child when DURATION_HOURS elapses.

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not $env:DURATION_HOURS) { $env:DURATION_HOURS = "5" }
New-Item -ItemType Directory -Force -Path .\logs | Out-Null

Write-Host "Installing runtime deps (torch-directml pulls a CPU torch build)..."
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install onnxruntime-openvino openvino 2>$null

Write-Host "Confirm DirectML device..."
python -c "import torch_directml; print('dml', torch_directml.is_available(), torch_directml.device_count(), torch_directml.device_name(0))"

$py = (Get-Command python).Source
$jobs = @()
foreach ($script in @("monitor.py", "cpu_pressure.py", "npu_flood.py", "train_directml.py")) {
    $jobs += Start-Process -FilePath $py -ArgumentList $script -WorkingDirectory $PSScriptRoot -PassThru -RedirectStandardOutput "logs\$script.out.log" -RedirectStandardError "logs\$script.err.log"
    Write-Host "started $script pid=$($jobs[-1].Id)"
}

Write-Host "Running for $env:DURATION_HOURS h. Tail logs\train_directml.out.log and logs\npu_flood.out.log"
Wait-Process -Id ($jobs | ForEach-Object { $_.Id })
Write-Host "all workers exited"
