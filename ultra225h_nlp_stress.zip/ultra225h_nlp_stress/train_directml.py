"""
5-hour NLP training on Intel Arc 130T via DirectML.

This is the training half of the Ultra 5 225H stress experiment.
DirectML binds to the iGPU (Arc 130T, ~63 INT8 TOPS), not the NPU.
NPU saturation is npu_flood.py. CPU saturation is the DataLoader plus cpu_pressure.py.

Wall clock is fixed (default 5h). The loop does not stop on a loss target.
"""

from __future__ import annotations

import json
import math
import os
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import torch_directml
except ImportError as exc:
    raise SystemExit(
        "torch-directml missing. On the 225H laptop run: pip install torch-directml"
    ) from exc


ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)

HOURS = float(os.environ.get("DURATION_HOURS", "5"))
SEQ = int(os.environ.get("SEQ_LEN", "192"))
D_MODEL = int(os.environ.get("D_MODEL", "384"))
N_LAYERS = int(os.environ.get("N_LAYERS", "6"))
N_HEADS = int(os.environ.get("N_HEADS", "6"))
VOCAB = int(os.environ.get("VOCAB", "16000"))
BATCH = int(os.environ.get("BATCH", "8"))
LR = float(os.environ.get("LR", "3e-4"))
LOG_EVERY = int(os.environ.get("LOG_EVERY", "20"))


class CausalSelfAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.0):
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError("d_model must divide n_heads")
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model)
        self.proj = nn.Linear(d_model, d_model)
        self.dropout = dropout

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, c = x.shape
        qkv = self.qkv(x).reshape(b, t, 3, self.n_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(self.head_dim))
        mask = torch.triu(torch.ones(t, t, device=x.device, dtype=torch.bool), diagonal=1)
        att = att.masked_fill(mask, float("-inf"))
        att = torch.softmax(att, dim=-1)
        y = (att @ v).transpose(1, 2).reshape(b, t, c)
        return self.proj(y)


class Block(nn.Module):
    def __init__(self, d_model: int, n_heads: int):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = CausalSelfAttention(d_model, n_heads)
        self.ln2 = nn.LayerNorm(d_model)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, 4 * d_model),
            nn.GELU(),
            nn.Linear(4 * d_model, d_model),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x


class TinyLM(nn.Module):
    """Decoder LM. Big enough to fill Arc 130T shared memory, small enough for 16 GB."""

    def __init__(self, vocab: int, d_model: int, n_layers: int, n_heads: int, seq: int):
        super().__init__()
        self.tok = nn.Embedding(vocab, d_model)
        self.pos = nn.Embedding(seq, d_model)
        self.blocks = nn.ModuleList(Block(d_model, n_heads) for _ in range(n_layers))
        self.ln = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab, bias=False)
        self.seq = seq

    def forward(self, idx: torch.Tensor, targets: torch.Tensor | None = None):
        b, t = idx.shape
        pos = torch.arange(t, device=idx.device)
        x = self.tok(idx) + self.pos(pos)
        for block in self.blocks:
            x = block(x)
        logits = self.head(self.ln(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss


def synthetic_batch(batch: int, seq: int, vocab: int, device: torch.device):
    """On-device token draw. Cheap, so the GPU is not waiting on a dataloader."""
    idx = torch.randint(0, vocab, (batch, seq), device=device)
    return idx[:, :-1], idx[:, 1:]


def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def main() -> None:
    if not torch_directml.is_available():
        raise SystemExit("DirectML device not available. Update the Intel Arc driver.")

    device = torch_directml.device(int(os.environ.get("DML_DEVICE", "0")))
    model = TinyLM(VOCAB, D_MODEL, N_LAYERS, N_HEADS, SEQ).to(device)
    optim = torch.optim.AdamW(model.parameters(), lr=LR, betas=(0.9, 0.95), weight_decay=0.01)

    params = count_params(model)
    deadline = time.time() + HOURS * 3600
    step = 0
    t0 = time.time()
    log_path = LOG_DIR / "train_directml.jsonl"
    print(
        f"device={device} params={params/1e6:.2f}M batch={BATCH} seq={SEQ} "
        f"layers={N_LAYERS} d={D_MODEL} hours={HOURS}",
        flush=True,
    )

    model.train()
    running = 0.0
    last = time.time()
    with log_path.open("w", encoding="utf-8") as fh:
        while time.time() < deadline:
            x, y = synthetic_batch(BATCH, SEQ, VOCAB, device)
            optim.zero_grad(set_to_none=True)
            _, loss = model(x, y)
            loss.backward()
            optim.step()
            step += 1
            # .item() syncs the DirectML queue. Do it only on log steps so the GPU stays full.
            if step % LOG_EVERY == 0:
                loss_v = float(loss.detach().to("cpu"))
                now = time.time()
                dt = now - last
                steps_per_s = LOG_EVERY / max(dt, 1e-6)
                tokens_per_s = steps_per_s * BATCH * (SEQ - 1)
                elapsed_h = (now - t0) / 3600
                row = {
                    "step": step,
                    "loss": round(loss_v, 4),
                    "elapsed_h": round(elapsed_h, 4),
                    "steps_per_s": round(steps_per_s, 3),
                    "tokens_per_s": round(tokens_per_s, 1),
                    "left_h": round(max(0.0, HOURS - elapsed_h), 4),
                }
                fh.write(json.dumps(row) + "\n")
                fh.flush()
                print(
                    f"step={step} loss={loss_v:.3f} tok/s={tokens_per_s:.0f} "
                    f"elapsed={elapsed_h:.2f}h left={row['left_h']:.2f}h",
                    flush=True,
                )
                last = now
                running = loss_v
                if step % (LOG_EVERY * 15) == 0:
                    ckpt = LOG_DIR / "tiny_lm_directml.pt"
                    torch.save({"step": step, "model": model.state_dict(), "loss": running}, ckpt)

    torch.save({"step": step, "model": model.state_dict()}, LOG_DIR / "tiny_lm_directml_final.pt")
    print(f"done steps={step} wall_h={(time.time()-t0)/3600:.3f}", flush=True)


if __name__ == "__main__":
    main()
