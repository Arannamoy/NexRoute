"""
NPU flood for Intel AI Boost on Core Ultra 5 225H (13 TOPS INT8).

Client NPUs do not train. This process keeps the NPU at maximum inference
pressure for the same wall clock as the DirectML training job.

Bind order:
  1. ONNX Runtime OpenVINO EP, device_type=NPU   (this is the real NPU path)
  2. OpenVINO runtime compile_model(..., "NPU")
  3. DirectML EP (lands on Arc 130T — logged as a miss, not a success)

The graph is a static-shape transformer-encoder block stack (NLP token
classifier). Static shapes are required for NPU compile.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)
MODEL_PATH = LOG_DIR / "npu_encoder.onnx"

HOURS = float(os.environ.get("DURATION_HOURS", "5"))
BATCH = int(os.environ.get("NPU_BATCH", "8"))
SEQ = int(os.environ.get("NPU_SEQ", "128"))
D_MODEL = int(os.environ.get("NPU_D", "256"))
N_LAYERS = int(os.environ.get("NPU_LAYERS", "4"))
N_HEADS = int(os.environ.get("NPU_HEADS", "4"))
VOCAB = int(os.environ.get("NPU_VOCAB", "8000"))
N_CLASS = 4


def build_onnx() -> None:
    import onnx
    from onnx import TensorProto, helper

    nodes = []
    inits = []
    seq = SEQ
    d = D_MODEL
    h = N_HEADS
    hd = d // h

    def w(name: str, shape: tuple[int, ...], scale: float = 0.02) -> str:
        arr = (np.random.randn(*shape).astype(np.float32) * scale)
        inits.append(helper.make_tensor(name, TensorProto.FLOAT, list(shape), arr.flatten().tolist()))
        return name

    # token ids -> embedding via Gather
    w("emb", (VOCAB, d))
    nodes.append(helper.make_node("Gather", ["emb", "input_ids"], ["x0"], axis=0))
    x = "x0"
    for i in range(N_LAYERS):
        w(f"wq{i}", (d, d))
        w(f"wk{i}", (d, d))
        w(f"wv{i}", (d, d))
        w(f"wo{i}", (d, d))
        w(f"w1{i}", (d, 4 * d))
        w(f"w2{i}", (4 * d, d))
        nodes.append(helper.make_node("MatMul", [x, f"wq{i}"], [f"q{i}"]))
        nodes.append(helper.make_node("MatMul", [x, f"wk{i}"], [f"k{i}"]))
        nodes.append(helper.make_node("MatMul", [x, f"wv{i}"], [f"v{i}"]))
        # reshape to heads: (B, S, H, Hd) -> (B, H, S, Hd)
        nodes.append(helper.make_node("Reshape", [f"q{i}", f"sh{i}"], [f"qr{i}"]))
        nodes.append(helper.make_node("Transpose", [f"qr{i}"], [f"qt{i}"], perm=[0, 2, 1, 3]))
        nodes.append(helper.make_node("Reshape", [f"k{i}", f"sh{i}"], [f"kr{i}"]))
        nodes.append(helper.make_node("Transpose", [f"kr{i}"], [f"kt{i}"], perm=[0, 2, 1, 3]))
        nodes.append(helper.make_node("Reshape", [f"v{i}", f"sh{i}"], [f"vr{i}"]))
        nodes.append(helper.make_node("Transpose", [f"vr{i}"], [f"vt{i}"], perm=[0, 2, 1, 3]))
        inits.append(
            helper.make_tensor(
                f"sh{i}",
                TensorProto.INT64,
                [4],
                [BATCH, seq, h, hd],
            )
        )
        nodes.append(helper.make_node("Transpose", [f"kt{i}"], [f"ktt{i}"], perm=[0, 1, 3, 2]))
        nodes.append(helper.make_node("MatMul", [f"qt{i}", f"ktt{i}"], [f"att{i}"]))
        scale = np.array(1.0 / np.sqrt(hd), dtype=np.float32)
        inits.append(helper.make_tensor(f"sc{i}", TensorProto.FLOAT, [1], scale.tolist()))
        nodes.append(helper.make_node("Mul", [f"att{i}", f"sc{i}"], [f"atts{i}"]))
        nodes.append(helper.make_node("Softmax", [f"atts{i}"], [f"attp{i}"], axis=-1))
        nodes.append(helper.make_node("MatMul", [f"attp{i}", f"vt{i}"], [f"ctx{i}"]))
        nodes.append(helper.make_node("Transpose", [f"ctx{i}"], [f"ctxt{i}"], perm=[0, 2, 1, 3]))
        inits.append(helper.make_tensor(f"shb{i}", TensorProto.INT64, [3], [BATCH, seq, d]))
        nodes.append(helper.make_node("Reshape", [f"ctxt{i}", f"shb{i}"], [f"ctxr{i}"]))
        nodes.append(helper.make_node("MatMul", [f"ctxr{i}", f"wo{i}"], [f"ao{i}"]))
        nodes.append(helper.make_node("Add", [x, f"ao{i}"], [f"res{i}"]))
        nodes.append(helper.make_node("MatMul", [f"res{i}", f"w1{i}"], [f"h1{i}"]))
        nodes.append(helper.make_node("Relu", [f"h1{i}"], [f"h1r{i}"]))
        nodes.append(helper.make_node("MatMul", [f"h1r{i}", f"w2{i}"], [f"h2{i}"]))
        nodes.append(helper.make_node("Add", [f"res{i}", f"h2{i}"], [f"x{i+1}"]))
        x = f"x{i+1}"

    # mean pool + classify
    nodes.append(helper.make_node("ReduceMean", [x], ["pooled"], axes=[1], keepdims=0))
    w("cls", (d, N_CLASS))
    nodes.append(helper.make_node("MatMul", ["pooled", "cls"], ["logits"]))

    graph = helper.make_graph(
        nodes,
        "npu_encoder",
        [helper.make_tensor_value_info("input_ids", TensorProto.INT64, [BATCH, SEQ])],
        [helper.make_tensor_value_info("logits", TensorProto.FLOAT, [BATCH, N_CLASS])],
        inits,
    )
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    onnx.save(model, MODEL_PATH)
    print(f"wrote {MODEL_PATH} ({MODEL_PATH.stat().st_size/1e6:.1f} MB)", flush=True)


def try_openvino_ep():
    import onnxruntime as ort

    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    providers = [
        (
            "OpenVINOExecutionProvider",
            {
                "device_type": "NPU",
                "precision": "ACCURACY",
                "num_of_threads": "4",
            },
        )
    ]
    sess = ort.InferenceSession(str(MODEL_PATH), sess_options=so, providers=providers)
    used = sess.get_providers()
    if "OpenVINOExecutionProvider" not in used:
        raise RuntimeError(f"OpenVINO EP not active, got {used}")
    return sess, "onnxruntime-openvino:NPU"


def try_openvino_native():
    import openvino as ov

    core = ov.Core()
    if "NPU" not in core.available_devices:
        raise RuntimeError(f"NPU not in OpenVINO devices: {core.available_devices}")
    compiled = core.compile_model(str(MODEL_PATH), "NPU")
    return compiled, "openvino:NPU"


def try_directml():
    import onnxruntime as ort

    sess = ort.InferenceSession(str(MODEL_PATH), providers=["DmlExecutionProvider", "CPUExecutionProvider"])
    used = sess.get_providers()
    if "DmlExecutionProvider" not in used:
        raise RuntimeError(f"DirectML EP not active, got {used}")
    return sess, "directml-ep:likely-igpu"


def bind():
    errors = []
    for fn in (try_openvino_ep, try_openvino_native, try_directml):
        try:
            handle, name = fn()
            return handle, name
        except Exception as exc:  # noqa: BLE001 — probe chain
            errors.append(f"{fn.__name__}: {exc}")
    raise SystemExit("NPU bind failed:\n" + "\n".join(errors))


def run_ort(sess, deadline: float, backend: str) -> None:
    log_path = LOG_DIR / "npu_flood.jsonl"
    step = 0
    t0 = time.time()
    last = t0
    ids = np.random.randint(0, VOCAB, size=(BATCH, SEQ), dtype=np.int64)
    with log_path.open("w", encoding="utf-8") as fh:
        while time.time() < deadline:
            out = sess.run(None, {"input_ids": ids})
            step += 1
            # mutate a slice so the compiler cannot DCE the call
            ids[0, 0] = (ids[0, 0] + int(out[0][0, 0]) + 1) % VOCAB
            if step % 50 == 0:
                now = time.time()
                row = {
                    "backend": backend,
                    "step": step,
                    "infer_per_s": round(50 / max(now - last, 1e-6), 2),
                    "tokens_per_s": round(50 * BATCH * SEQ / max(now - last, 1e-6), 1),
                    "elapsed_h": round((now - t0) / 3600, 4),
                }
                fh.write(json.dumps(row) + "\n")
                fh.flush()
                print(
                    f"npu step={step} infer/s={row['infer_per_s']} tok/s={row['tokens_per_s']} "
                    f"elapsed={row['elapsed_h']}h backend={backend}",
                    flush=True,
                )
                last = now


def run_ov(compiled, deadline: float, backend: str) -> None:
    infer = compiled.create_infer_request()
    log_path = LOG_DIR / "npu_flood.jsonl"
    step = 0
    t0 = time.time()
    last = t0
    ids = np.random.randint(0, VOCAB, size=(BATCH, SEQ), dtype=np.int64)
    with log_path.open("w", encoding="utf-8") as fh:
        while time.time() < deadline:
            infer.infer({"input_ids": ids})
            step += 1
            ids[0, 0] = (ids[0, 0] + 1) % VOCAB
            if step % 50 == 0:
                now = time.time()
                row = {
                    "backend": backend,
                    "step": step,
                    "infer_per_s": round(50 / max(now - last, 1e-6), 2),
                    "tokens_per_s": round(50 * BATCH * SEQ / max(now - last, 1e-6), 1),
                    "elapsed_h": round((now - t0) / 3600, 4),
                }
                fh.write(json.dumps(row) + "\n")
                fh.flush()
                print(
                    f"npu step={step} infer/s={row['infer_per_s']} tok/s={row['tokens_per_s']} "
                    f"elapsed={row['elapsed_h']}h backend={backend}",
                    flush=True,
                )
                last = now


def main() -> None:
    build_onnx()
    handle, backend = bind()
    print(f"bound {backend}", flush=True)
    (LOG_DIR / "npu_backend.txt").write_text(backend, encoding="utf-8")
    deadline = time.time() + HOURS * 3600
    if backend.startswith("openvino:"):
        run_ov(handle, deadline, backend)
    else:
        run_ort(handle, deadline, backend)


if __name__ == "__main__":
    main()
