# Ultra 5 225H — 5-ghonta NLP stress (CPU + NPU, DirectML)

Laptop: Intel Core Ultra 5 225H (Arrow Lake-H). 14 core / 14 thread (4P + 8E + 2 LP-E), 28 W base, turbo up to 115 W. AI split Intel-er number: CPU ~7 TOPS, Arc 130T iGPU ~63 TOPS, Intel AI Boost NPU 13 TOPS, total 83 TOPS INT8.

## Jeta actually pressure dey

Client NPU backpropagation kore na. DirectML training Arc 130T iGPU-te boshe (DX12). Intel NPU-ke framework list-e DirectML dey, kintu Windows-e NPU saturate korar production path OpenVINO / Windows ML inference. Tai experiment ta tin process:

| Process | Ki kore | Ki bhore |
| --- | --- | --- |
| `train_directml.py` | 6-layer causal LM, DirectML device 0 | Arc 130T + kichu CPU (AdamW, sync) |
| `npu_flood.py` | static-shape encoder, INT8-friendly MatMul stack, infinite infer | NPU (OpenVINO EP `device_type=NPU`) |
| `cpu_pressure.py` | 10 worker: n-gram hash + 768-d GEMM | baki P/E cores |
| `monitor.py` | per-core CPU % + RAM | proof je CPU full chilo |

Wall clock fixed, default 5 hour. Loss target nai — loop deadline porjonto chole.

## Chalano

Power plan: Best performance. Plugged in. Lid open, fan unobstructed. 16 GB RAM hole `BATCH=4` rakhben; 32 GB hole default `BATCH=8` thik.

```powershell
cd ultra225h_nlp_stress
powershell -ExecutionPolicy Bypass -File .\run_5h.ps1
```

Custom:

```powershell
$env:DURATION_HOURS = "5"
$env:BATCH = "4"          # 16 GB shared memory hole
$env:SEQ_LEN = "128"
$env:CPU_WORKERS = "8"    # LP-E duita OS-er jonno chere din
powershell -ExecutionPolicy Bypass -File .\run_5h.ps1
```

NPU driver: Device Manager > Neural processors > Intel(R) AI Boost. Driver purono hole NPU bind fail korbe, log-e `directml-ep:likely-igpu` ashbe — ota miss, success na.

## Log

- `logs/train_directml.jsonl` — step, loss, tokens/s
- `logs/npu_flood.jsonl` — infer/s, backend name
- `logs/npu_backend.txt` — `onnxruntime-openvino:NPU` hole NPU dhoreche
- `logs/monitor.jsonl` — cpu_avg. 5h dhore ~80%+ hole CPU pressure thik
- `logs/tiny_lm_directml_final.pt` — sesh checkpoint

Task Manager: GPU 0 (Arc) 3D/Compute high, Neural processor high, CPU package ~thermal limit. 10–20 min por PL1-e nebe (28–45 W). Ota chassis limit, script-er bug na.

## Keno eta "robust"

- DirectML training real backprop (attention + MLP + CE), synthetic token stream, dataloader wait nai.
- NPU graph static shape, opset 17, Gather/MatMul/Softmax/Relu — OpenVINO NPU je ops cover kore tar bhitor.
- Bind fail hole chain: OpenVINO EP NPU → native `compile_model(..., "NPU")` → DirectML EP. Last ta iGPU, log-e alada.
- Checkpoint every ~300 log steps, crash hole `logs/tiny_lm_directml.pt` theke resume manually kora jay.
