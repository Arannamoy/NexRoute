"""Sample CPU (and GPU engine, if the counter exists) while the 5h run is up."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import psutil

ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)
HOURS = float(os.environ.get("DURATION_HOURS", "5"))


def main() -> None:
    deadline = time.time() + HOURS * 3600
    path = LOG_DIR / "monitor.jsonl"
    psutil.cpu_percent(interval=None)
    with path.open("w", encoding="utf-8") as fh:
        while time.time() < deadline:
            per = psutil.cpu_percent(interval=2, percpu=True)
            row = {
                "t": round(time.time(), 1),
                "cpu_avg": round(sum(per) / max(len(per), 1), 1),
                "cpu_max": round(max(per) if per else 0, 1),
                "cpu_per": [round(x, 1) for x in per],
                "ram_pct": round(psutil.virtual_memory().percent, 1),
            }
            fh.write(json.dumps(row) + "\n")
            fh.flush()
            print(f"cpu_avg={row['cpu_avg']} cpu_max={row['cpu_max']} ram={row['ram_pct']}", flush=True)


if __name__ == "__main__":
    main()
