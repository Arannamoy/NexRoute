"""
CPU-side NLP pressure for the 14-thread Ultra 5 225H (4P+8E+2LP-E).

DirectML training and the NPU flood do not fill every core. This process
pins the rest with tokenization, n-gram hashing, and AVX2/VNNI-friendly GEMM
— the same kind of work a real NLP dataloader + embedding stage does.
"""

from __future__ import annotations

import json
import os
import time
from multiprocessing import Process
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)

HOURS = float(os.environ.get("DURATION_HOURS", "5"))
WORKERS = int(os.environ.get("CPU_WORKERS", "10"))
D = int(os.environ.get("CPU_D", "768"))


def worker(wid: int, deadline: float) -> None:
    rng = np.random.default_rng(wid + 7)
    # int8 GEMM is what DL Boost / VNNI likes; fp32 keeps the E-cores busy too
    a = rng.standard_normal((256, D), dtype=np.float32)
    b = rng.standard_normal((D, D), dtype=np.float32)
    vocab = 32000
    text = rng.integers(0, vocab, size=(8192,), dtype=np.int32)
    hashes = 0
    gemm = 0
    t0 = time.time()
    last = t0
    path = LOG_DIR / f"cpu_worker_{wid}.jsonl"
    with path.open("w", encoding="utf-8") as fh:
        while time.time() < deadline:
            # fake BPE: windowed hash over token stream
            grams = text[:-2] * 1315423911 + text[1:-1] * 2654435761 + text[2:]
            grams = grams % vocab
            text[: len(grams)] = grams
            hashes += 1
            c = a @ b
            a = c[:256] * 0.999 + 0.001
            gemm += 1
            if gemm % 20 == 0:
                now = time.time()
                row = {
                    "worker": wid,
                    "gemm": gemm,
                    "hash": hashes,
                    "gemm_per_s": round(20 / max(now - last, 1e-6), 2),
                    "elapsed_h": round((now - t0) / 3600, 4),
                }
                fh.write(json.dumps(row) + "\n")
                fh.flush()
                last = now


def main() -> None:
    deadline = time.time() + HOURS * 3600
    procs = [Process(target=worker, args=(i, deadline), daemon=True) for i in range(WORKERS)]
    for p in procs:
        p.start()
    print(f"cpu pressure workers={WORKERS} hours={HOURS}", flush=True)
    for p in procs:
        p.join()
    print("cpu pressure done", flush=True)


if __name__ == "__main__":
    main()
